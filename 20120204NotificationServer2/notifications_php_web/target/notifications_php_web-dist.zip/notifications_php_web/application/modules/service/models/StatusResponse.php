<?php
class StatusResponse
{
	public $status = "failed";
}