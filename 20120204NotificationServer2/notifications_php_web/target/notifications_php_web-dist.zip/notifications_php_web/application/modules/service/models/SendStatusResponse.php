<?php
class SendStatusResponse
{
	public $status = "failed";
	public $mid = "-1";
}