<?php
class NotificationsResult
{
	public $result;
	public function NotificationsResult($res)
	{
		$this->result = $res;
	}
}