<?php
class CountResponse
{	
	public $count = 0;
}