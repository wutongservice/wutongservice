<?php

require_once 'PHPUnit/Framework/TestCase.php';

class IndexControllerTest extends PHPUnit_Framework_TestCase
{

    public function setUp()
    {
        /* Setup Routine */
    }

    public function tearDown()
    {
        /* Tear Down Routine */
    }

	public function testTest()
	{
		echo "This is a IndexControllerTest!\n";
	}
}

